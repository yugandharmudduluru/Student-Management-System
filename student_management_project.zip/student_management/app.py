from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="your_password",
    database="student_db"
)
cursor = conn.cursor()

@app.route('/')
def index():
    cursor.execute("SELECT * FROM students")
    data = cursor.fetchall()
    return render_template('index.html', students=data)

@app.route('/add', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        course = request.form['course']
        cursor.execute("INSERT INTO students (name, email, phone, course) VALUES (%s, %s, %s, %s)",
                       (name, email, phone, course))
        conn.commit()
        return redirect('/')
    return render_template('add.html')

@app.route('/delete/<int:id>')
def delete_student(id):
    cursor.execute("DELETE FROM students WHERE id = %s", (id,))
    conn.commit()
    return redirect('/')

@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update_student(id):
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        course = request.form['course']
        cursor.execute("UPDATE students SET name=%s, email=%s, phone=%s, course=%s WHERE id=%s",
                       (name, email, phone, course, id))
        conn.commit()
        return redirect('/')
    cursor.execute("SELECT * FROM students WHERE id = %s", (id,))
    student = cursor.fetchone()
    return render_template('update.html', student=student)

if __name__ == '__main__':
    app.run(debug=True)